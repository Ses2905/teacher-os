---
name: unit-planner
description: Plan grade 6-7 US history units from standards, calendar, instructional time, existing resources, and assessment goals. Use for unit maps, pacing guides, lesson sequences, essential questions, vocabulary, or backward planning.
---

# Unit Planner

Create a coherent unit arc: essential question, standards supplied by teacher, enduring understandings, lesson sequence, key vocabulary, formative checks, culminating assessment, and optional enrichment/remediation. Respect actual school calendar and minutes. Do not invent state/district standards; label suggested standards as suggestions unless supplied.
