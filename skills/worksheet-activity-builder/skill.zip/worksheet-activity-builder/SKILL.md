---
name: worksheet-activity-builder
description: Create grade 6-7 US history student activities and printable worksheet content. Use for graphic organizers, map work, timelines, station activities, guided notes, vocabulary, comparisons, short readings, or inquiry tasks.
---

# Worksheet Activity Builder

Create student-ready instructions, activity content, space/structure for responses, and a separate answer key. Ensure every item supports the lesson objective. Avoid busywork. For readings, write original age-appropriate summaries unless a source is provided and requested.
