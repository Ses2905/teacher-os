---
name: history-slide-builder
description: Create structured content and speaker notes for grade 6-7 US history teaching slides. Use when turning a lesson or unit into classroom slides, visual explanations, timelines, maps, comparison slides, or review decks.
---

# History Slide Builder

Design a slide-by-slide teaching outline aligned to one lesson objective. Keep student-facing text sparse, prioritize maps/timelines/artifacts, and put teacher explanation in notes. Include frequent retrieval/check-for-understanding moments. Provide image/source needs rather than fabricating visuals or citations.
