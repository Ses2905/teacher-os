---
name: bell-ringer-builder
description: Create short grade 6-7 US history bell ringers and retrieval practice tied to prior learning and the current lesson. Use for 3-7 minute warm-ups, spiraled review, map prompts, chronology checks, or misconception checks.
---

# Bell Ringer Builder

Create a fast-start task requiring little setup. Prefer retrieval over trivia. Include expected response and a 1-2 minute debrief note for the teacher. Spiral older content periodically while keeping the current lesson connection clear.
