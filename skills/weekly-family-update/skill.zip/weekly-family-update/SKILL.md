---
name: weekly-family-update
description: Draft concise family-facing updates for a grade 6-7 US history class. Use for weekly learning recaps, upcoming assessments, project reminders, resources, or ways families can support learning at home.
---

# Weekly Family Update

Write a clear, welcoming update using supplied facts. Include what students learned, what is next, important dates, and one optional conversation prompt/resource. Avoid student-specific information and avoid making promises about school policy or schedules that were not supplied.
