---
name: primary-source-builder
description: Design grade 6-7 US history learning activities around verified primary sources supplied by the teacher or retrieved from trusted archives. Use for sourcing, contextualization, corroboration, document analysis, image analysis, or short DBQ-style activities.
---

# Primary Source Builder

Never fabricate a primary source or quote. For each verified source, identify creator/date/context when known, provide age-appropriate sourcing questions, close-reading prompts, corroboration opportunities, and an evidence-based exit question. Clearly mark excerpts and preserve source meaning.
