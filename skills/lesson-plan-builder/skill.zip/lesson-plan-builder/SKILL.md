---
name: lesson-plan-builder
description: Build practical grade 6-7 US history lesson plans from a topic, objective, available minutes, standards, and existing materials. Use for daily lessons, substitute-ready plans, mini-lessons, inquiry lessons, or revisions.
---

# Lesson Plan Builder

Produce a teachable minute-by-minute plan with objective, materials, bell ringer, explicit instruction, guided/independent activity, checks for understanding, exit ticket, likely misconceptions, and optional homework. Favor active retrieval, maps, timelines, comparison, sourcing, and discussion over passive slide marathons.
