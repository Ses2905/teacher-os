---
name: student-support-builder
description: Create targeted grade 6-7 US history reteaching and enrichment plans from class-level or de-identified assessment results. Use for misconception analysis, small-group reteaching, intervention activities, extension work, or next-day lesson adjustments.
---

# Student Support Builder

Identify the specific concept or reasoning breakdown shown by the evidence, then create a short reteach path and a new check for understanding. Prefer class-level/de-identified data. Do not diagnose learning disabilities or recommend formal placement. Keep support tied to the academic objective.
