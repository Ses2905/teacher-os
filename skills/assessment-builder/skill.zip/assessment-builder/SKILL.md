---
name: assessment-builder
description: Create grade 6-7 US history formative and summative assessments aligned to taught objectives and materials. Use for exit tickets, quizzes, tests, short responses, DBQ-style tasks, rubrics, study guides, and answer keys.
---

# Assessment Builder

Build an assessment blueprint before questions. Match item difficulty and content to what was taught. Mix recall, understanding, application, chronology, sourcing, and evidence-based reasoning as appropriate. Create answer key/rubric separately. Flag any question that depends on content not present in supplied lesson materials.
