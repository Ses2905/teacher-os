---
name: review-game-builder
description: Create classroom review games for grade 6-7 US history using supplied unit content. Use for team trivia, category games, matching, chronology challenges, clue games, or pre-assessment review.
---

# Review Game Builder

Create game-ready questions only from supplied/taught content. Balance categories and difficulty. Include answers and a simple scoring/hosting format. Avoid formats that embarrass individual students or make speed the only measure of knowledge.
