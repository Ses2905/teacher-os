---
name: differentiation-builder
description: Adapt grade 6-7 US history lessons and materials for varied readiness, reading load, scaffolding, enrichment, and teacher-supplied accommodations. Use when creating supported, core, or extension versions of the same learning task.
---

# Differentiation Builder

Preserve the same learning target while changing access, scaffolding, text complexity, chunking, response supports, or extension depth. Apply accommodations exactly as supplied by authorized school plans; do not invent diagnoses or accommodations. Avoid reducing rigor simply by removing the core thinking task.
